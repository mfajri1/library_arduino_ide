﻿#ifndef LEDONOFF_h
#define LEDONOFF_h

#include "Arduino.h"

#define dOFF 0
#define dON 1
#define dTONE   2000

class LedOnOff {
    private:
        char          m_name;
        int8_t        m_ledPin;
        unsigned long m_onoffInt;
        unsigned long m_startMillies;
        int8_t        m_lState;
        int8_t        m_on;
        int8_t        m_buzzer;
        int           m_tone;
    public:
        LedOnOff(char a_name, int8_t aledPin, unsigned long aonoffInt, int8_t aBuzzer, int a_tone);
        void Off();
        void OnOff(unsigned long start);
        void Preveri(unsigned long aMillies);
};

#endif
