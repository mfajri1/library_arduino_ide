﻿#include "Arduino.h"
#include "LedOnOff.h"

LedOnOff::LedOnOff(char a_name, int8_t aledPin, unsigned long aonoffInt, int8_t aBuzzer, int a_tone) {
    m_name = a_name;
    m_ledPin = aledPin;
    m_onoffInt = aonoffInt;
    m_buzzer = aBuzzer;
    m_startMillies = 0;
    m_lState = dOFF;
    m_on = dOFF;
    m_tone = a_tone;
}

void LedOnOff::Off() {
    if (m_lState == dON) {
        Serial.print(m_name);
        Serial.println(" led OFF");
        digitalWrite(m_ledPin, LOW);
        m_lState = dOFF;
        noTone(m_buzzer);    
    }
    m_on = dOFF;
}

void LedOnOff::OnOff(unsigned long start) {
    Serial.print(m_name);
    if (m_on == dOFF) {
        Serial.println(" led ON");
        digitalWrite(m_ledPin, HIGH);
        tone(m_buzzer, m_tone);
        m_lState = dON;
        m_on = dON;
        m_startMillies = start;
    }
    else {
        Serial.println(" led OFF");
        digitalWrite(m_ledPin, LOW);
        noTone(m_buzzer);    
        m_lState = dOFF;
        m_on = dOFF;
    }
}

void LedOnOff::Preveri(unsigned long aMillies) {
    
    if (m_on == dOFF) return;
    
    boolean checkit = (((float)(aMillies - m_startMillies) / (float)m_onoffInt) - (int)((float)(aMillies - m_startMillies) / (float)m_onoffInt)) < 0.5 ? false : true;
    Serial.print("Interval: ");
    Serial.println(checkit);

    if (checkit) {
        if (m_lState == dON) {
            digitalWrite(m_ledPin, LOW);
            m_lState = dOFF;
            noTone(m_buzzer);    
            Serial.print(m_name);
            Serial.println(" led OFF");
        }
    }
    else {
        if (m_lState == dOFF) {
            digitalWrite(m_ledPin, HIGH);
            m_lState = dON;
            tone(m_buzzer, m_tone);
            Serial.print(m_name);
            Serial.println(" led ON");
        }
    }
}

